php server.php
exec $0 $@;
